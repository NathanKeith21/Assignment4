﻿using Assignment4.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;

namespace Assignment4.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            List<string> RestaurantList = new List<string>();

            foreach(Restaurant r in Restaurant.GetRestaurants())
            {
                string? Dish = r.FavDish ?? "It's all tasty!";
                RestaurantList.Add($"#{r.Ranking}: {r.Name}, Favorite Dish: {Dish}, Address: {r.Address}, Phone Number: {r.PhoneNum}, Website: {r.Website}");
            }


            return View(RestaurantList);
        }
        [Microsoft.AspNetCore.Mvc.HttpGet]
        public IActionResult SuggestRestaurant()
        {
            return View();
        }
        [Microsoft.AspNetCore.Mvc.HttpPost]
        public IActionResult SuggestRestaurant(SuggestionResponse Suggestions)
        {
            if (ModelState.IsValid)
            {
                SuggestionList.AddApplication(Suggestions);
                return View("Confirmation", Suggestions);
            }
            return View();
        }
        public IActionResult List()
        {
            return View(SuggestionList.Suggestions);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
