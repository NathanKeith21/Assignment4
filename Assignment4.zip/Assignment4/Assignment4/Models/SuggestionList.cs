﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//this code helps handle the suggested restaurant data, so it can be used throughout the website
namespace Assignment4.Models
{
    public class SuggestionList
    {
        private static List<SuggestionResponse> suggestions = new List<SuggestionResponse>();

        public static IEnumerable<SuggestionResponse> Suggestions => suggestions;

        public static void AddApplication(SuggestionResponse suggestion)
        {
            suggestions.Add(suggestion);
        }
    }
}