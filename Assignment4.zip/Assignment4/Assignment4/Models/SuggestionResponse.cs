﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment4.Models
{
    public class SuggestionResponse
    {
        public string PersonName { get; set; }
        public string RestaurantName { get; set; }
        public string FavDish { get; set; }
        public uint PhoneNum { get; set; }
    }
}
