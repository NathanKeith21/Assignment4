﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment4.Models
{
    public class Restaurant
    {
        [Required]
        public int Ranking { get; set; }
        [Required]
        public string Name { get; set; }
        public string? FavDish { get; set; }
        [Required]
        public string Address { get; set; }
        public uint? PhoneNum { get; set; }
        public string? Website { get; set; } = "Coming soon";

        public static Restaurant[] GetRestaurants()
        {
            Restaurant r1 = new Restaurant
            {
                Ranking = 1,
                Name = "McDonalds",
                FavDish = "McBurger",
                Address = "123 Diabetes Road",
                PhoneNum = 3057502393,
                Website = "mcdonalds.com"
            };
            Restaurant r2 = new Restaurant
            {
                Ranking = 2,
                Name = "Panda Express",
                FavDish = "Sweetfire Chicken",
                Address = "123 MSG Road",
                PhoneNum = 3057502593,
                Website = "pandaexpress.com"
            };
            Restaurant r3 = new Restaurant
            {
                Ranking = 3,
                Name = "Blaze Pizza",
                Address = "123 Pizza Heaven"
            };
            Restaurant r4 = new Restaurant
            {
                Ranking = 4,
                Name = "Mo Bettah's",
                FavDish = "Tuloa Pig",
                Address = "123 Macaroni Lane",
                PhoneNum = 3057502823,
                Website = "mobettahs.com"
            };
            Restaurant r5 = new Restaurant
            {
                Ranking = 5,
                Name = "Sushi Ya",
                FavDish = "Godzilla Roll",
                Address = "123 All-You-Can-Eat Road",
                PhoneNum = 3057502590,
                Website = "sushiya.com"
            };
            return new Restaurant[] { r1, r2, r3, r4, r5 };
        }
    }
}
